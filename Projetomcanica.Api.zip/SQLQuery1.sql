create table usuario (
id Int primary key ,
nome  varchar(50),
usuario varchar (10),
senha varchar(8)
);

create table cliente (
id int primary key,
nome varchar (50),
Cpf varchar (11),
Telefone varchar (9),
email varchar (50)
)

create table veiculo (
id int primary key,
Cliente_id int foreign key references clientes(id),
placa varchar (7),
marca varchar (10),
modelo varchar (10),
cor varchar (10)
)

create table agendamento(
id int primary key,
data date ,
servico varchar (20),
Veiculo_id  int foreign key references veiculos(id)
)