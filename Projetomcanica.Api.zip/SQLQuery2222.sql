INSERT INTO usuario (id, nome, usuario, senha)
VALUES
(1, 'Leticia Costa', 'leticia', '123456'),
(2, 'Joao Silva', 'joao', '123456'),
(3, 'Maria Santos', 'maria', '654321'),
(4, 'Pedro Oliveira', 'pedro', '123789'),
(5, 'Ana Souza', 'ana', '987654');

INSERT INTO agendamento(id, data, servico, Veiculo_id)
VALUES
(1, '2026-10-01', 'Troca de oleo', 1),
(2, '2026-10-02', 'Alinhamento', 2),
(3, '2026-10-03', 'Balanceamento', 3),
(4, '2026-10-04', 'Revisao', 4),
(5, '2026-10-05', 'Troca de pneus', 5),
(6, '2026-10-06', 'Troca de oleo', 2),
(7, '2026-10-07', 'Revisao', 1);

INSERT INTO cliente (id, nome, Cpf, Telefone, email)
VALUES
(1, 'Carlos Almeida', '12345678901', '999999999', 'carlos@gmail.com'),
(2, 'Mariana Oliveira', '23456789012', '988888888', 'mariana@gmail.com'),
(3, 'Rafael Santos', '34567890123', '977777777', 'rafael@gmail.com'),
(4, 'Juliana Costa', '45678901234', '966666666', 'juliana@gmail.com'),
(5, 'Gabriel Souza', '56789012345', '955555555', 'gabriel@gmail.com');



INSERT INTO veiculo (id, Cliente_id, placa, marca, modelo, cor)
VALUES
(1, 1, 'ABC1234', 'Toyota', 'Corolla', 'Prata'),
(2, 2, 'DEF5678', 'Honda', 'Civic', 'Preto'),
(3, 3, 'GHI9012', 'Volkswagen', 'Gol', 'Branco'),
(4, 4, 'JKL3456', 'Chevrolet', 'Onix', 'Vermelho'),
(5, 5, 'MNO7890', 'Fiat', 'Argo', 'Cinza');
